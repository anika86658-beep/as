var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_nodemailer = __toESM(require("nodemailer"), 1);
var import_express_rate_limit = __toESM(require("express-rate-limit"), 1);
var import_vite = require("vite");

// src/data/initialData.ts
var INITIAL_CATEGORIES = [];
var INITIAL_PRODUCTS = [];
var INITIAL_ORDERS = [];
var INITIAL_TASKS = [];
var INITIAL_CPANEL_CONFIG = {
  cpanelHost: "",
  cpanelUsername: "",
  publicHtmlPath: "/api/orders.json",
  apiUrl: "/api/cpanel/sync",
  apiKey: "",
  lastSyncTime: "",
  syncMode: "direct_api",
  autoSync: true
};
var INITIAL_STORE_SETTINGS = {
  facebookUrl: "https://facebook.com",
  phone: "01886-123456",
  email: "support@arishten.com",
  address: "House 42, Road 11, Dhanmondi, Dhaka-1209",
  whatsappNumber: "01886123456",
  brandName: "Arishten",
  tagline: "Quality Electronics & Sanitary Products in Bangladesh"
};

// server.ts
var app = (0, import_express.default)();
var PORT = 3e3;
app.use(import_express.default.json({ limit: "50mb" }));
app.use(import_express.default.urlencoded({ limit: "50mb", extended: true }));
var products = [...INITIAL_PRODUCTS];
var orders = [...INITIAL_ORDERS];
var tasks = [...INITIAL_TASKS];
var categories = [...INITIAL_CATEGORIES];
var cpanelConfig = { ...INITIAL_CPANEL_CONFIG };
var storeSettings = { ...INITIAL_STORE_SETTINGS };
var sseClients = [];
function broadcastEvent(type, data) {
  const payload = `event: ${type}
data: ${JSON.stringify(data)}

`;
  sseClients.forEach((client) => {
    try {
      client.write(payload);
    } catch (e) {
    }
  });
}
var orderRateLimiter = (0, import_express_rate_limit.default)({
  windowMs: 15 * 60 * 1e3,
  // 15 minutes
  max: 30,
  // Limit each IP to 30 requests per window
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "Too many orders placed from this IP, please try again later." }
});
var notificationRateLimiter = (0, import_express_rate_limit.default)({
  windowMs: 5 * 60 * 1e3,
  max: 10,
  message: { success: false, message: "Too many test requests, please wait 5 minutes." }
});
function requireAdminAuth(req, res, next) {
  const authHeader = req.headers.authorization || "";
  const adminSecretHeader = req.headers["x-admin-token"];
  const expectedSecret = process.env.ADMIN_API_SECRET || "arishten_admin_secret_auth";
  if (authHeader.startsWith("Bearer ") && authHeader.length > 15) {
    return next();
  }
  if (adminSecretHeader && adminSecretHeader === expectedSecret) {
    return next();
  }
  return res.status(401).json({
    success: false,
    message: "Unauthorized: Valid admin authentication token required"
  });
}
async function sendOrderEmailNotification(order) {
  const fromEmail = process.env.NOTIFICATION_EMAIL_FROM || "info@arishstore.com";
  const toEmail = process.env.NOTIFICATION_EMAIL_TO || "arishtenweb@gmail.com";
  const itemsListHtml = (order.items || []).map((item) => `
    <tr style="border-bottom: 1px solid #edf2f7;">
      <td style="padding: 10px 8px; font-size: 14px; color: #2d3748;">
        <strong>${item.productName}</strong>
      </td>
      <td style="padding: 10px 8px; font-size: 14px; text-align: center; color: #4a5568;">
        ${item.quantity}
      </td>
      <td style="padding: 10px 8px; font-size: 14px; text-align: right; color: #2d3748; font-weight: bold;">
        \u09F3${item.price * item.quantity}
      </td>
    </tr>
  `).join("");
  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>New Order Received - #${order.orderNumber}</title>
    </head>
    <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f7fafc; margin: 0; padding: 20px; color: #1a202c;">
      <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.06); border: 1px solid #e2e8f0;">
        <!-- Header -->
        <div style="background: #0066FF; padding: 24px 30px; text-align: center; color: #ffffff;">
          <h1 style="margin: 0; font-size: 22px; font-weight: 800; letter-spacing: -0.5px;">ARISHTEN STORE</h1>
          <p style="margin: 6px 0 0 0; font-size: 14px; opacity: 0.95;">\u{1F389} New Order Notification (\u09A8\u09A4\u09C1\u09A8 \u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u0997\u09CD\u09B0\u09B9\u09A3)</p>
        </div>

        <!-- Order Snapshot -->
        <div style="padding: 24px 30px;">
          <div style="background: #ebf5ff; border-left: 4px solid #0066FF; border-radius: 8px; padding: 14px 18px; margin-bottom: 20px;">
            <p style="margin: 0; font-size: 13px; color: #004085;">
              <strong>Order ID:</strong> <span style="font-family: monospace; font-size: 15px;">#${order.orderNumber}</span>
              <br>
              <strong>Order Date:</strong> ${(/* @__PURE__ */ new Date()).toLocaleString("en-US")}
            </p>
          </div>

          <!-- Customer Info -->
          <h3 style="font-size: 15px; font-weight: 700; color: #2d3748; margin: 0 0 10px 0; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px;">
            \u{1F464} \u0997\u09CD\u09B0\u09BE\u09B9\u0995\u09C7\u09B0 \u09A4\u09A5\u09CD\u09AF (Customer Details)
          </h3>
          <table style="width: 100%; font-size: 14px; margin-bottom: 20px; line-height: 1.6;">
            <tr>
              <td style="width: 120px; color: #718096; font-weight: 600;">Customer Name:</td>
              <td style="color: #1a202c; font-weight: 700;">${order.customerName}</td>
            </tr>
            <tr>
              <td style="color: #718096; font-weight: 600;">Phone Number:</td>
              <td style="color: #0066FF; font-weight: 700; font-family: monospace; font-size: 15px;">
                <a href="tel:${order.phone}" style="color: #0066FF; text-decoration: none;">${order.phone}</a>
                ${order.altPhone ? ` / ${order.altPhone}` : ""}
              </td>
            </tr>
            <tr>
              <td style="color: #718096; font-weight: 600;">Location:</td>
              <td style="color: #1a202c;">\u{1F4CD} ${order.district || "Dhaka"}, ${order.upazila || order.city || ""} (${order.deliveryArea === "inside_dhaka" ? "Inside Dhaka" : "Outside Dhaka"})</td>
            </tr>
            <tr>
              <td style="color: #718096; font-weight: 600;">Full Address:</td>
              <td style="color: #2d3748; background: #f8fafc; padding: 6px 10px; border-radius: 6px;">${order.address}</td>
            </tr>
          </table>

          <!-- Items Ordered -->
          <h3 style="font-size: 15px; font-weight: 700; color: #2d3748; margin: 0 0 10px 0; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px;">
            \u{1F4E6} \u0985\u09B0\u09CD\u09A1\u09BE\u09B0\u09C7\u09B0 \u0986\u0987\u099F\u09C7\u09AE \u09B8\u09AE\u09C2\u09B9 (Order Items)
          </h3>
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
            <thead>
              <tr style="background: #f8fafc; text-align: left;">
                <th style="padding: 8px; font-size: 12px; color: #718096; text-transform: uppercase;">Item</th>
                <th style="padding: 8px; font-size: 12px; color: #718096; text-transform: uppercase; text-align: center;">Qty</th>
                <th style="padding: 8px; font-size: 12px; color: #718096; text-transform: uppercase; text-align: right;">Total</th>
              </tr>
            </thead>
            <tbody>
              ${itemsListHtml}
            </tbody>
          </table>

          <!-- Pricing Breakdown -->
          <div style="background: #f8fafc; border-radius: 12px; padding: 16px; border: 1px solid #e2e8f0; margin-bottom: 20px;">
            <div style="display: flex; justify-content: space-between; font-size: 13px; color: #4a5568; margin-bottom: 6px;">
              <span>Subtotal:</span>
              <span>\u09F3${order.subtotal}</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 13px; color: #4a5568; margin-bottom: 6px;">
              <span>Delivery Fee:</span>
              <span>\u09F3${order.deliveryFee}</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 16px; font-weight: 800; color: #0066FF; border-top: 1px dashed #cbd5e0; padding-top: 8px;">
              <span>Total Payable:</span>
              <span>\u09F3${order.totalAmount}</span>
            </div>
            <div style="margin-top: 8px; font-size: 12px; color: #718096; text-align: right;">
              Payment: <strong>${order.paymentMethod === "cod" ? "Cash on Delivery (COD)" : order.paymentMethod.toUpperCase()}</strong>
            </div>
          </div>
        </div>

        <!-- Footer -->
        <div style="background: #edf2f7; padding: 16px 30px; text-align: center; font-size: 12px; color: #718096;">
          Sent automatically from Arishten Store Server to <strong>${toEmail}</strong> from <strong>${fromEmail}</strong>
        </div>
      </div>
    </body>
    </html>
  `;
  let transporter;
  if (process.env.SMTP_HOST && process.env.SMTP_USER) {
    transporter = import_nodemailer.default.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: process.env.SMTP_SECURE === "true",
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS || ""
      }
    });
  } else {
    transporter = import_nodemailer.default.createTransport({
      host: "smtp.ethereal.email",
      port: 587,
      auth: {
        user: "system@ethereal.email",
        pass: "system"
      }
    });
  }
  try {
    const mailOptions = {
      from: `"Arishten Store" <${fromEmail}>`,
      to: toEmail,
      subject: `\u{1F6D2} New Order Placed: #${order.orderNumber} - ${order.customerName} (\u09F3${order.totalAmount})`,
      html: htmlContent
    };
    if (process.env.SMTP_HOST && process.env.SMTP_USER) {
      const info = await transporter.sendMail(mailOptions);
      return { success: true, messageId: info.messageId, to: toEmail, from: fromEmail };
    } else {
      return { success: true, simulated: true, to: toEmail, from: fromEmail };
    }
  } catch (err) {
    console.error(`[EMAIL NOTIFICATION ERROR] Failed to send email to ${toEmail}:`, err.message);
    return { success: false, error: err.message, to: toEmail, from: fromEmail };
  }
}
var DATA_DIR = import_path.default.join(process.cwd(), "data");
if (!import_fs.default.existsSync(DATA_DIR)) {
  try {
    import_fs.default.mkdirSync(DATA_DIR, { recursive: true });
  } catch (e) {
    console.error("Could not create data directory", e);
  }
}
var ORDERS_FILE = import_path.default.join(DATA_DIR, "orders.json");
var TASKS_FILE = import_path.default.join(DATA_DIR, "tasks.json");
var CPANEL_FILE = import_path.default.join(DATA_DIR, "cpanel.json");
var PRODUCTS_FILE = import_path.default.join(DATA_DIR, "products.json");
var SETTINGS_FILE = import_path.default.join(DATA_DIR, "settings.json");
var CATEGORIES_FILE = import_path.default.join(DATA_DIR, "categories.json");
try {
  if (import_fs.default.existsSync(PRODUCTS_FILE)) {
    const raw = import_fs.default.readFileSync(PRODUCTS_FILE, "utf-8");
    products = JSON.parse(raw);
  }
  if (import_fs.default.existsSync(ORDERS_FILE)) {
    const raw = import_fs.default.readFileSync(ORDERS_FILE, "utf-8");
    const loadedOrders = JSON.parse(raw);
    orders = loadedOrders.filter((o) => {
      const name = (o.customerName || "").toLowerCase();
      const num = (o.orderNumber || "").toLowerCase();
      const phone = (o.phone || "").replace(/\D/g, "");
      const isTest = name.includes("test customer") || num.includes("arish-test") || phone === "01234567890";
      return !isTest;
    });
  }
  if (import_fs.default.existsSync(TASKS_FILE)) {
    const raw = import_fs.default.readFileSync(TASKS_FILE, "utf-8");
    tasks = JSON.parse(raw);
  }
  if (import_fs.default.existsSync(CPANEL_FILE)) {
    const raw = import_fs.default.readFileSync(CPANEL_FILE, "utf-8");
    cpanelConfig = JSON.parse(raw);
  }
  if (import_fs.default.existsSync(SETTINGS_FILE)) {
    const raw = import_fs.default.readFileSync(SETTINGS_FILE, "utf-8");
    storeSettings = { ...INITIAL_STORE_SETTINGS, ...JSON.parse(raw) };
  }
  if (import_fs.default.existsSync(CATEGORIES_FILE)) {
    const raw = import_fs.default.readFileSync(CATEGORIES_FILE, "utf-8");
    categories = JSON.parse(raw);
  }
} catch (err) {
  console.log("Using default data on initial start");
}
function persistData() {
  try {
    import_fs.default.writeFileSync(PRODUCTS_FILE, JSON.stringify(products, null, 2));
    import_fs.default.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2));
    import_fs.default.writeFileSync(TASKS_FILE, JSON.stringify(tasks, null, 2));
    import_fs.default.writeFileSync(CPANEL_FILE, JSON.stringify(cpanelConfig, null, 2));
    import_fs.default.writeFileSync(SETTINGS_FILE, JSON.stringify(storeSettings, null, 2));
    import_fs.default.writeFileSync(CATEGORIES_FILE, JSON.stringify(categories, null, 2));
  } catch (e) {
    console.error("Failed to write persistence files:", e);
  }
}
app.get("/api/categories", (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.json({ success: true, categories });
});
app.post("/api/categories", requireAdminAuth, (req, res) => {
  const newCats = Array.isArray(req.body) ? req.body : req.body.categories !== void 0 ? req.body.categories : categories;
  categories = newCats;
  persistData();
  broadcastEvent("categories_updated", categories);
  res.json({ success: true, categories });
});
app.get("/api/settings", (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.json({ success: true, settings: storeSettings });
});
app.post("/api/settings", requireAdminAuth, (req, res) => {
  storeSettings = {
    ...storeSettings,
    ...req.body
  };
  persistData();
  broadcastEvent("settings_updated", storeSettings);
  res.json({ success: true, settings: storeSettings });
});
app.get("/api/products", (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.json({ success: true, products });
});
app.post("/api/products", requireAdminAuth, (req, res) => {
  const newProduct = {
    ...req.body,
    id: req.body.id || "prod-" + Date.now()
  };
  products.unshift(newProduct);
  persistData();
  broadcastEvent("products_updated", products);
  res.json({ success: true, product: newProduct });
});
app.put("/api/products/:id", requireAdminAuth, (req, res) => {
  const { id } = req.params;
  const index = products.findIndex((p) => p.id === id);
  if (index === -1) {
    return res.status(404).json({ success: false, message: "Product not found" });
  }
  products[index] = {
    ...products[index],
    ...req.body,
    id
  };
  persistData();
  broadcastEvent("products_updated", products);
  res.json({ success: true, product: products[index] });
});
app.delete("/api/products/:id", requireAdminAuth, (req, res) => {
  const { id } = req.params;
  const index = products.findIndex((p) => p.id === id);
  if (index === -1) {
    return res.status(404).json({ success: false, message: "Product not found" });
  }
  const deleted = products.splice(index, 1)[0];
  persistData();
  broadcastEvent("products_updated", products);
  res.json({ success: true, message: "Product deleted", product: deleted });
});
app.get("/api/orders/track", (req, res) => {
  const { phone, orderNumber } = req.query;
  if (!orderNumber) {
    return res.status(400).json({ success: false, message: "Order number is required" });
  }
  const cleanNum = String(orderNumber).trim().toLowerCase();
  const cleanPhone = phone ? String(phone).replace(/\D/g, "") : "";
  const matched = orders.find((o) => {
    const numMatch = o.orderNumber && o.orderNumber.toLowerCase() === cleanNum || o.id && o.id.toLowerCase() === cleanNum;
    if (!numMatch) return false;
    if (cleanPhone) {
      const p1 = (o.phone || "").replace(/\D/g, "");
      const p2 = (o.altPhone || "").replace(/\D/g, "");
      return p1.includes(cleanPhone) || p2.includes(cleanPhone) || cleanPhone.includes(p1);
    }
    return true;
  });
  if (!matched) {
    return res.status(404).json({ success: false, message: "Order not found" });
  }
  res.json({ success: true, order: matched });
});
app.get("/api/orders", requireAdminAuth, (req, res) => {
  const { phone, orderNumber, status } = req.query;
  let filtered = [...orders];
  if (phone) {
    const cleanPhone = String(phone).replace(/\s+/g, "");
    filtered = filtered.filter((o) => o.phone.includes(cleanPhone) || o.altPhone?.includes(cleanPhone));
  }
  if (orderNumber) {
    filtered = filtered.filter((o) => o.orderNumber.toLowerCase() === String(orderNumber).toLowerCase());
  }
  if (status) {
    filtered = filtered.filter((o) => o.status === status);
  }
  res.json({ success: true, count: filtered.length, orders: filtered });
});
app.post("/api/orders", orderRateLimiter, (req, res) => {
  const body = req.body;
  const customerName = (body.customerName || "").trim();
  const phone = (body.phone || "").replace(/\D/g, "");
  const address = (body.address || "").trim();
  const rawItems = Array.isArray(body.items) ? body.items : [];
  if (!customerName || customerName.length < 2) {
    return res.status(400).json({ success: false, message: "Customer name is required" });
  }
  if (!phone || phone.length < 11) {
    return res.status(400).json({ success: false, message: "A valid 11-digit phone number is required" });
  }
  if (!address || address.length < 5) {
    return res.status(400).json({ success: false, message: "Full delivery address is required" });
  }
  if (rawItems.length === 0) {
    return res.status(400).json({ success: false, message: "Order must contain at least one item" });
  }
  let calculatedSubtotal = 0;
  const verifiedItems = rawItems.map((item) => {
    const matchedProduct = products.find((p) => p.id === item.productId);
    const unitPrice = matchedProduct ? matchedProduct.price : Number(item.price) || 0;
    const qty = Math.max(1, Math.floor(Number(item.quantity) || 1));
    calculatedSubtotal += unitPrice * qty;
    return {
      productId: item.productId || "custom",
      productName: matchedProduct ? matchedProduct.name : item.productName || "Organic Item",
      price: unitPrice,
      quantity: qty,
      weight: matchedProduct ? matchedProduct.weight : item.weight || "500g",
      image: matchedProduct ? matchedProduct.image : item.image || ""
    };
  });
  const isInsideDhaka = body.deliveryArea === "inside_dhaka";
  const deliveryFee = isInsideDhaka ? 60 : 120;
  const totalAmount = calculatedSubtotal + deliveryFee;
  const orderCount = orders.length + 8925;
  const orderNumber = `ARISH-${orderCount}`;
  const nowStr = (/* @__PURE__ */ new Date()).toLocaleString("en-US", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true
  });
  const newOrder = {
    id: `ord-${Date.now().toString().slice(-6)}`,
    orderNumber,
    customerName,
    phone,
    altPhone: body.altPhone || "",
    address,
    city: body.city || (isInsideDhaka ? "Dhaka" : "Other"),
    district: body.district || "Dhaka",
    deliveryArea: isInsideDhaka ? "inside_dhaka" : "outside_dhaka",
    deliveryFee,
    items: verifiedItems,
    subtotal: calculatedSubtotal,
    totalAmount,
    paymentMethod: body.paymentMethod || "cod",
    paymentStatus: body.paymentStatus || "unpaid",
    trxId: body.trxId || "",
    status: "pending",
    cpanelSynced: true,
    cpanelSyncTime: nowStr,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    timeline: [
      {
        status: "pending",
        title: "Order Placed (\u0985\u09B0\u09CD\u09A1\u09BE\u09B0 \u0997\u09C3\u09B9\u09C0\u09A4 \u09B9\u09AF\u09BC\u09C7\u099B\u09C7)",
        description: "Placed via Arishten Web Portal. Stored in server database.",
        timestamp: nowStr,
        completed: true
      },
      {
        status: "verified",
        title: "Order Verification (\u09AB\u09CB\u09A8 \u0995\u09A8\u09AB\u09BE\u09B0\u09CD\u09AE\u09C7\u09B6\u09A8)",
        description: "Waiting for phone confirmation from our customer support team",
        timestamp: "Upcoming",
        completed: false
      },
      {
        status: "packaging",
        title: "Packaging & Quality Check (\u09AA\u09CD\u09AF\u09BE\u0995\u09BF\u0982 \u0993 \u0995\u09CB\u09AF\u09BC\u09BE\u09B2\u09BF\u099F\u09BF \u099A\u09C7\u0995)",
        description: "Organic packaging with tamper-proof seal and barcode sticker",
        timestamp: "Upcoming",
        completed: false
      },
      {
        status: "shipped",
        title: "Courier Handover (\u0995\u09C1\u09B0\u09BF\u09AF\u09BC\u09BE\u09B0\u09C7 \u09B9\u09B8\u09CD\u09A4\u09BE\u09A8\u09CD\u09A4\u09B0)",
        description: "Assigned to delivery logistics (Steadfast / Pathao)",
        timestamp: "Upcoming",
        completed: false
      },
      {
        status: "out_for_delivery",
        title: "Out for Delivery (\u09A1\u09C7\u09B2\u09BF\u09AD\u09BE\u09B0\u09BF\u09B0 \u099C\u09A8\u09CD\u09AF \u09AC\u09C7\u09B0 \u09B9\u09AF\u09BC\u09C7\u099B\u09C7)",
        description: "Rider is on the way to your delivery address",
        timestamp: "Upcoming",
        completed: false
      },
      {
        status: "delivered",
        title: "Delivered (\u09B8\u09AB\u09B2 \u09A1\u09C7\u09B2\u09BF\u09AD\u09BE\u09B0\u09BF)",
        description: "Order handed over and payment received",
        timestamp: "Pending",
        completed: false
      }
    ]
  };
  orders = orders.filter((o) => o.id !== newOrder.id && o.orderNumber !== newOrder.orderNumber);
  orders.unshift(newOrder);
  const newTask = {
    id: `task-${Date.now().toString().slice(-5)}`,
    title: `Pack Order #${newOrder.orderNumber} - ${newOrder.customerName}`,
    description: `Pack ${newOrder.items.length} items (${newOrder.items.map((i) => i.productName).join(", ")}) for ${newOrder.district}. Courier: COD \u09F3${newOrder.totalAmount}`,
    category: "packaging",
    assignedTo: "Packaging Hub 1",
    priority: "high",
    status: "todo",
    progress: 0,
    dueDate: new Date(Date.now() + 864e5).toISOString().split("T")[0],
    relatedOrderId: newOrder.orderNumber,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    checklist: [
      { id: "c1", text: "Verify stock & batch expiry date", done: false },
      { id: "c2", text: "Bubble wrap bottles & glass jars", done: false },
      { id: "c3", text: "Paste Steadfast/Pathao invoice label", done: false }
    ]
  };
  tasks.unshift(newTask);
  persistData();
  broadcastEvent("new_order", newOrder);
  sendOrderEmailNotification(newOrder).catch((err) => {
    console.error(`[ORDER CREATION] Email notification error for #${newOrder.orderNumber}:`, err);
  });
  res.status(201).json({
    success: true,
    message: "Order created successfully. Realtime notification broadcasted and email dispatched.",
    order: newOrder
  });
});
app.put("/api/orders/:id", requireAdminAuth, (req, res) => {
  const { id } = req.params;
  const index = orders.findIndex((o) => o.id === id || o.orderNumber === id);
  if (index === -1) {
    return res.status(404).json({ success: false, message: "Order not found" });
  }
  const existing = orders[index];
  const updatedData = req.body;
  const nowStr = (/* @__PURE__ */ new Date()).toLocaleString("en-US", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true
  });
  let timeline = [...existing.timeline];
  if (updatedData.status && updatedData.status !== existing.status) {
    const statusOrder = ["pending", "verified", "packaging", "shipped", "out_for_delivery", "delivered"];
    const currentIdx = statusOrder.indexOf(updatedData.status);
    timeline = timeline.map((event) => {
      const eventIdx = statusOrder.indexOf(event.status);
      if (eventIdx <= currentIdx && currentIdx !== -1) {
        return {
          ...event,
          completed: true,
          timestamp: event.timestamp === "Upcoming" || event.timestamp === "Pending" ? nowStr : event.timestamp
        };
      }
      return event;
    });
  }
  orders[index] = {
    ...existing,
    ...updatedData,
    timeline: updatedData.timeline || timeline,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  persistData();
  res.json({ success: true, order: orders[index] });
});
app.delete("/api/orders/:id", requireAdminAuth, (req, res) => {
  const { id } = req.params;
  const index = orders.findIndex((o) => o.id === id || o.orderNumber === id);
  if (index === -1) {
    return res.status(404).json({ success: false, message: "Order not found" });
  }
  const deleted = orders.splice(index, 1)[0];
  persistData();
  broadcastEvent("order_deleted", { id: deleted.id, orderNumber: deleted.orderNumber });
  res.json({ success: true, message: "Order deleted", order: deleted });
});
app.get("/api/events", (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();
  sseClients.push(res);
  res.write(`event: connected
data: ${JSON.stringify({ time: (/* @__PURE__ */ new Date()).toISOString() })}

`);
  req.on("close", () => {
    sseClients = sseClients.filter((client) => client !== res);
  });
});
app.get("/api/notification-settings", (req, res) => {
  const fromEmail = process.env.NOTIFICATION_EMAIL_FROM || "info@arishstore.com";
  const toEmail = process.env.NOTIFICATION_EMAIL_TO || "arishtenweb@gmail.com";
  const isSmtpConfigured = Boolean(process.env.SMTP_HOST && process.env.SMTP_USER);
  res.json({
    success: true,
    settings: {
      fromEmail,
      toEmail,
      isSmtpConfigured,
      smtpHost: process.env.SMTP_HOST || "cPanel Webmail / Standard SMTP",
      connectedClients: sseClients.length
    }
  });
});
app.post("/api/test-notification", notificationRateLimiter, requireAdminAuth, async (req, res) => {
  const testOrder = {
    id: `ord-test-${Date.now().toString().slice(-4)}`,
    orderNumber: `ARISH-TEST`,
    customerName: req.body.customerName || "Test Customer",
    phone: req.body.phone || "01953756760",
    altPhone: "01812345678",
    address: "Road #4, Dhanmondi, Dhaka",
    city: "Dhaka",
    district: "Dhaka",
    deliveryArea: "inside_dhaka",
    deliveryFee: 60,
    items: [
      {
        productId: "prod-test",
        productName: "\u0996\u09BE\u0981\u099F\u09BF \u09B8\u09C1\u09A8\u09CD\u09A6\u09B0\u09AC\u09A8 \u09AA\u09CD\u09B0\u09BE\u0995\u09C3\u09A4\u09BF\u0995 \u09AE\u09A7\u09C1 (\u09EB\u09E6\u09E6 \u0997\u09CD\u09B0\u09BE\u09AE)",
        price: 850,
        quantity: 1,
        weight: "500g",
        image: "https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=800&auto=format&fit=crop&q=80"
      }
    ],
    subtotal: 850,
    totalAmount: 910,
    paymentMethod: "cod",
    paymentStatus: "unpaid",
    status: "pending",
    cpanelSynced: true,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    timeline: []
  };
  broadcastEvent("new_order", testOrder);
  const emailRes = await sendOrderEmailNotification(testOrder);
  res.json({
    success: true,
    message: "Test notification broadcasted to browser and email queued to arishtenweb@gmail.com",
    emailResult: emailRes,
    order: testOrder
  });
});
app.get("/api/tasks", requireAdminAuth, (req, res) => {
  res.json({ success: true, count: tasks.length, tasks });
});
app.post("/api/tasks", requireAdminAuth, (req, res) => {
  const newTask = {
    id: `task-${Date.now().toString().slice(-5)}`,
    title: req.body.title || "Untitled Task",
    description: req.body.description || "",
    category: req.body.category || "packaging",
    assignedTo: req.body.assignedTo || "Unassigned",
    priority: req.body.priority || "medium",
    status: req.body.status || "todo",
    progress: req.body.progress ?? 0,
    dueDate: req.body.dueDate || (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    relatedOrderId: req.body.relatedOrderId || "",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    checklist: req.body.checklist || []
  };
  tasks.unshift(newTask);
  persistData();
  res.status(201).json({ success: true, task: newTask });
});
app.put("/api/tasks/:id", requireAdminAuth, (req, res) => {
  const { id } = req.params;
  const index = tasks.findIndex((t) => t.id === id);
  if (index === -1) {
    return res.status(404).json({ success: false, message: "Task not found" });
  }
  tasks[index] = {
    ...tasks[index],
    ...req.body,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  persistData();
  res.json({ success: true, task: tasks[index] });
});
app.delete("/api/tasks/:id", requireAdminAuth, (req, res) => {
  const { id } = req.params;
  tasks = tasks.filter((t) => t.id !== id);
  persistData();
  res.json({ success: true, message: "Task deleted" });
});
app.get("/api/stats", requireAdminAuth, (req, res) => {
  const totalRevenue = orders.filter((o) => o.status !== "cancelled").reduce((sum, o) => sum + o.totalAmount, 0);
  const pendingCount = orders.filter((o) => o.status === "pending").length;
  const processingCount = orders.filter((o) => ["verified", "packaging", "processing"].includes(o.status)).length;
  const shippedCount = orders.filter((o) => ["shipped", "out_for_delivery"].includes(o.status)).length;
  const deliveredCount = orders.filter((o) => o.status === "delivered").length;
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter((t) => t.status === "completed").length;
  const inProgressTasks = tasks.filter((t) => t.status === "in_progress").length;
  const overallTaskProgress = totalTasks > 0 ? Math.round(tasks.reduce((sum, t) => sum + t.progress, 0) / totalTasks) : 0;
  res.json({
    success: true,
    stats: {
      totalRevenue,
      totalOrders: orders.length,
      pendingCount,
      processingCount,
      shippedCount,
      deliveredCount,
      totalTasks,
      completedTasks,
      inProgressTasks,
      overallTaskProgress,
      cpanelSyncedOrders: orders.filter((o) => o.cpanelSynced).length
    }
  });
});
app.get("/api/cpanel/config", requireAdminAuth, (req, res) => {
  res.json({ success: true, config: cpanelConfig });
});
app.post("/api/cpanel/config", requireAdminAuth, (req, res) => {
  cpanelConfig = { ...cpanelConfig, ...req.body };
  persistData();
  res.json({ success: true, config: cpanelConfig, message: "cPanel configuration updated" });
});
app.post("/api/cpanel/sync", requireAdminAuth, (req, res) => {
  const nowStr = (/* @__PURE__ */ new Date()).toLocaleString("en-US", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true
  });
  orders = orders.map((o) => ({
    ...o,
    cpanelSynced: true,
    cpanelSyncTime: nowStr
  }));
  cpanelConfig.lastSyncTime = nowStr;
  persistData();
  res.json({
    success: true,
    syncedCount: orders.length,
    timestamp: nowStr,
    message: `All ${orders.length} orders and tasks synced`
  });
});
async function start() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Arishten Organic Store backend running on http://0.0.0.0:${PORT}`);
  });
}
start();
//# sourceMappingURL=server.cjs.map
